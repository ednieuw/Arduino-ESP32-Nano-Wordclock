// SPDX-License-Identifier: LGPL-3.0-or-later
// Copyright 2016-2025 Hristo Gochkov, Mathieu Carbou, Emil Muratov
#pragma once

#warning "AsyncMessagePack.h is deprecated, just include ESPAsyncWebServer.h from now on"

#include "AsyncJson.h"
