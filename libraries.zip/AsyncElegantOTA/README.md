# (Deprecated) AsyncElegantOTA

AsyncElegantOTA has been **deprecated** and it is NOT recommended for usage. Please consider migrating to **[ElegantOTA](https://github.com/ayushsharma82/ElegantOTA) which now comes with async mode**. Learn More on async mode: https://docs.elegantota.pro/async-mode/

---

**ElegantOTA** is the latest library that is much more reliable and has an advanced upload mechanism.
